import React from 'react';
import MainPage from './MainPage'; // Adjust the path according to your file structure

function App() {
  return (
    <div className="App">
      <MainPage />
    </div>
  );
}

export default App;
